﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;





namespace kursa4
{
    public partial class FormMain : Form
    {
        string name;
        List<Dot> DotList = new List<Dot>();
        List<double> CheckListX = new List<double>();
        List<double> CheckListY = new List<double>();
        int count = 0;

        public FormMain(string userName)
        {

            InitializeComponent();
            name = userName;
        }


        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (Regex.IsMatch(textBoxInsert.Text, "^(\\s+)?[0-9]*[.,]?[0-9]+(\\s+)?\\;(\\s+)?[0-9]*[.,]?[0-9]+(\\s+)?$"))
            {

                if (!Initialize(textBoxInsert.Text))
                {
                    textBoxInsert.Text = "";
                    MessageBox.Show("Такая точка уже есть!");
                }
                else
                {
                    textBoxInsert.Text = "";
                    MessageBox.Show("Точка добавлена!");
                    buttonSave.Visible = false;
                }
            }
            else
            {
                if (textBoxInsert.Text == "")
                {
                    MessageBox.Show("Поле пустое!");
                }
                MessageBox.Show("Введено неверное значение!");
            }
        }

        private bool Initialize(string text)
        {
            text = text.Replace(" ", "");
            double x = Double.Parse(text.Substring(0, text.IndexOf(";")));
            double y = Double.Parse(text.Substring(text.LastIndexOf(";") + 1));
            Dot dot = new Dot(x, y, count);
            count++;
            if ((CheckListX.Contains(dot.getX())) && (CheckListY.Contains(dot.getY())))
            {
                return false;
            }
            else
            {
                DotList.Add(dot);
                CheckListX.Add(dot.getX());
                CheckListY.Add(dot.getY());
                return true;
            }
        }

        private void InsertInDB(string user, double dist)
        {
            chart1.Visible = true;
            try
            {
                SQLiteConnection DB = new SQLiteConnection("Data Source=DB.db; Version=3");
                DB.Open();
                SQLiteCommand CMD = DB.CreateCommand();
                CMD.CommandText = "INSERT INTO 'history' ('user', 'dist') VALUES ('" + name + "', '" + dist.ToString() + "')";
                CMD.ExecuteNonQuery();
                DB.Close();
            }
            catch
            {

            }
        }

        private void buttonDraw_Click(object sender, EventArgs e)
        {
            if (DotList.Count >= 3)
            {

                double[] x = new double[DotList.Count + 1];
                double[] y = new double[DotList.Count + 1];


                Algorithm a = new Algorithm(DotList);
                DotList = a.getList();
                InsertInDB(name, a.getDistance());

                for (int i = 0; i < x.Length; i++)
                {
                    x[i] = DotList[i].getX();
                    y[i] = DotList[i].getY();
                }

                double Xmax = x[0];
                for (int i = 1; i < x.Length; i++)
                {
                    if (x[i] > Xmax)
                        Xmax = x[i];
                }

                chart1.ChartAreas[0].AxisX.Minimum = 0;
                chart1.ChartAreas[0].AxisX.Maximum = Xmax;
                chart1.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
                chart1.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
                chart1.Series[0].Points.DataBindXY(x, y);

                chart1.Series[0].ToolTip = "X = #VALX, Y = #VALY";

                chart1.Series["Series1"].Points[0].Label = "start";
                for (int i = 1; i < x.Length - 1; i++)
                {
                    chart1.Series["Series1"].Points[i].Label = i.ToString();
                }


                DotList.Clear();
                CheckListX.Clear();
                CheckListY.Clear();
                buttonSave.Visible = true;
            }
            else
            {
                MessageBox.Show("Недостаточно точек!");
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
                using (SaveFileDialog sfd = new SaveFileDialog())
                {
                    sfd.Title = "Сохранить изображение как ...";
                    sfd.Filter = "*.jpg|*.jpg;|*.png|*.png;|*.bmp|*.bmp";
                    sfd.AddExtension = true;
                    sfd.FileName = "graphicImage";
                    if (sfd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        switch (sfd.FilterIndex)
                        {
                            case 1: chart1.SaveImage(sfd.FileName, ChartImageFormat.Jpeg); break;
                            case 2: chart1.SaveImage(sfd.FileName, ChartImageFormat.Png); break;
                            case 3: chart1.SaveImage(sfd.FileName, ChartImageFormat.Bmp); break;
                        }
                    }
                }
        }

        private void MainClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Для решения задачи Коммивояжёра нужно поочерёдно ввести координаты точек в формате \"x;y\" (при вводе десятичной дроби разделителем должна служить запятая, т.к. точка вызовет ошибку). "+
                "Чтобы добавить точку нажмите \"Добавить\". Поле ввода автоматически станет пустым и готовым к вводу новой точки. Всего точек должно быть больше двух. "+
                "Кнопка \"Нарисовать\" соединит заданные точки методом ближайшего соседа. Первая заданная точка будет считаться первоначальной. Результат можно сохранить картинкой в форматах png, jpg и bmp.", "Справка");
        }
    }
}
