﻿using System;
using System.Data.SQLite;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace kursa4
{
    public partial class Registration : Form
    {
        public Registration()
        {
            InitializeComponent();
        }

        private void RegistrationForm_Load(object sender, EventArgs e)
        {

        }

        public string Login { get; }
        public string Password { get; }

        private string Hash(string input)
        {
            SHA1Managed sha1 = new SHA1Managed();
            var hash = sha1.ComputeHash(Encoding.UTF8.GetBytes(input));
            var sb = new StringBuilder(hash.Length * 2);
            foreach (byte b in hash)
            {
                sb.Append(b.ToString("x2"));
            }
            return sb.ToString();
        }



        private void RegisterButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (!nameRegBox.Text.Equals("") && !passRegBox.Text.Equals("") && !logRegBox.Text.Equals(""))
                {
                    if (!nameRegBox.Text.Trim().Contains(" ") && !logRegBox.Text.Trim().Contains(" "))
                    {
                        if (Char.IsLetter(nameRegBox.Text[0]) && Char.IsLetter(logRegBox.Text[0]))
                        {
                            if (!File.Exists("DB.db")) // если базы данных нету, то...
                            {
                                SQLiteConnection.CreateFile("DB.db"); // создать базу данных, по указанному пути содаётся пустой файл базы данных
                                using (SQLiteConnection Connect = new SQLiteConnection("Data Source=DB.db;Version=3;")) // в строке указывается к какой базе подключаемся
                                {
                                    // строка запроса, который надо будет выполнить на базе
                                    string commandText = "CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name VARCHAR (50) NOT NULL, " +
                                        "login VARCHAR(50) NOT NULL, password VARCHAR(50) NOT NULL);" +
                                    "CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, user VARCHAR(50) NOT NULL, dist VARCHAR(50) NOT NULL);";                                                        // создать таблицу, если её нет
                                    SQLiteCommand Command = new SQLiteCommand(commandText, Connect);
                                    Connect.Open();
                                    int _result = Command.ExecuteNonQuery();
                                    Connect.Close();
                                }
                            }
                            SQLiteConnection DB = new SQLiteConnection("Data Source=DB.db; Version=3");
                            DB.Open();
                            SQLiteCommand CMDa = DB.CreateCommand();
                            CMDa.CommandText = "select * from users where login = @login";
                            CMDa.Parameters.Add("@login", System.Data.DbType.String).Value = logRegBox.Text;
                            SQLiteDataReader SQL = CMDa.ExecuteReader();

                            if (!SQL.HasRows)
                            {
                                SQLiteCommand CMD = DB.CreateCommand();
                                CMD.CommandText = "insert into users(name, login, password) values( @name, @login, @password)";
                                CMD.Parameters.Add("@name", System.Data.DbType.String).Value = nameRegBox.Text;
                                CMD.Parameters.Add("@login", System.Data.DbType.String).Value = logRegBox.Text;
                                CMD.Parameters.Add("@password", System.Data.DbType.String).Value = Hash(passRegBox.Text);
                                CMD.ExecuteNonQuery();
                                DB.Close();
                                DB = null;
                                CMD = null;
                                CMDa = null;
                                MessageBox.Show("Вы успешно зарегистрировались!");
                                this.Hide();
                                FormAuth f = new FormAuth();
                                f.Show();
                            }
                            else
                            {
                                SQL.Close();
                                DB.Close();
                                DB = null;
                                CMDa = null;
                                MessageBox.Show("Такой пользователь уже существует!");
                                nameRegBox.Text = "";
                                logRegBox.Text = "";
                                passRegBox.Text = "";
                            }

                        }
                        else
                        {
                            MessageBox.Show("Имя и Логин должны начинаться с буквы!");
                            nameRegBox.Text = "";
                            logRegBox.Text = "";
                            passRegBox.Text = "";
                        }
                    }
                    else
                    {
                        MessageBox.Show("Имя и Логин не могут содержать пробелы!");
                        nameRegBox.Text = "";
                        logRegBox.Text = "";
                        passRegBox.Text = "";
                    }
                }
                else
                {
                    MessageBox.Show("Вы ввели не все значения!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
            }
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormAuth Auth = new FormAuth();
            Auth.Show();
        }

        private void RegClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
