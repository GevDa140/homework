﻿using System;
using System.Data.SQLite;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace kursa4
{
    public partial class FormAuth : Form
    {
        public FormAuth()
        {
            InitializeComponent();
        }

        private void FormAuth_Load(object sender, EventArgs e)
        {

        }


        private void authButton_Click(object sender, EventArgs e)
        {
            try
            {
                SQLiteConnection DB = new SQLiteConnection("Data Source=DB.db; Version=3");
                DB.Open();
                SQLiteCommand CMD = DB.CreateCommand();
                CMD.CommandText = "select * from users where login = @login and password = @password";
                CMD.Parameters.Add("@login", System.Data.DbType.String).Value = textBoxLogin.Text;
                CMD.Parameters.Add("@password", System.Data.DbType.String).Value = Hash(textBoxPass.Text);

                SQLiteDataReader SQL = CMD.ExecuteReader();
                if (SQL.HasRows)
                {
                    FormMain f = new FormMain(textBoxLogin.Text);
                    f.Left = this.Left;
                    f.Top = this.Top;
                    f.Show();
                    DB.Close();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Неправильно введён логин и/или пароль!");
                }
            }
            catch
            {
                MessageBox.Show("Вы не зарегистрировались!", "Ошибка!");
            }
        }

        private void registerButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            var new_user = new Registration();
            new_user.Closed += (s, args) => this.Close();
            new_user.Show();
        }


        private string Hash(string input)
        {
            SHA1Managed sha1 = new SHA1Managed();
            var hash = sha1.ComputeHash(Encoding.UTF8.GetBytes(input));
            var sb = new StringBuilder(hash.Length * 2);
            foreach (byte b in hash)
            {
                sb.Append(b.ToString("x2"));
            }
            return sb.ToString();
        }

        private void AuthClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
