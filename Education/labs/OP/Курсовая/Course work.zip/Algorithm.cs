﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Math;

namespace kursa4
{
    public class Algorithm
    {
        private double distance;
        private List<Dot> listTrueDots = new List<Dot>();
        private List<int> listVer = new List<int>();
        private List<Dot> listDotsDist;
        public Algorithm(List<Dot> dots)
        {
            Convertor(dots);
        }

        private void Convertor(List<Dot> dots)
        {
            listDotsDist = dots;
            Dot startDot = dots[0];
            listTrueDots.Add(dots[0]);
            listVer.Add(0);
            Compare(dots, startDot);
            listTrueDots.Add(dots[0]);
        }

        public List<Dot> getList()
        {
            return listTrueDots;
        }

        public double getDistance()
        {
            return distance + Sqrt(Pow(Abs(listDotsDist[0].getX() - listDotsDist[listVer[listVer.Count - 1]].getX()), 2)
                        + Pow(Abs(listDotsDist[0].getY() - listDotsDist[listVer[listVer.Count - 1]].getY()), 2));
        }

        private Dot Compare(List<Dot> dots, Dot startDot)
        {
            double thisDistance = -1;
            double Tdistance = 0;
            int num = -1;
            for (int i = 0; i < dots.Count; i++)
            {
                if (!listVer.Contains(i))
                {
                    thisDistance = Sqrt(Pow(Abs(startDot.getX() - dots[i].getX()), 2)
                        + Pow(Abs(startDot.getY() - dots[i].getY()), 2));
                    if (Tdistance == 0 || Tdistance > thisDistance)
                    {
                        Tdistance = thisDistance;
                        num = i;
                        thisDistance = 0;
                    }
                }
            }
            if (num == -1)
            {
                return null;
            }
            else
            {
                distance = distance + Tdistance;
                listVer.Add(num);
                listTrueDots.Add(dots[num]);
                return Compare(dots, dots[num]);
            }
        }
    }
}
