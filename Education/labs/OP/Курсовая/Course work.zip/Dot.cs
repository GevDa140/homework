﻿namespace kursa4
{
    public class Dot
    {
        private double x { get; set; }
        private double y { get; set; }
        private int number { get; set; }


        public Dot(double x, double y, int number)
        {
            this.number = number;
            this.x = x;
            this.y = y;

        }

        public double getX()
        {
            return x;
        }

        public double getY()
        {
            return y;
        }
        public int getNumber()
        {
            return number;
        }
    }
}
